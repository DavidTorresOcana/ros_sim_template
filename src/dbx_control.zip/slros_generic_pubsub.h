/* Copyright 2015 The MathWorks, Inc. */

#include <iostream>
#include <ros/ros.h>
#include <ros/callback_queue.h>

extern ros::NodeHandle * SLROSNodePtr; 

//---------------------------------
// Subscriber template

template <class MsgType, class BusType>
class SimulinkSubscriber
{
public:
  void sub_callback(const boost::shared_ptr<MsgType const>&);
  void create_subscriber(std::string const& topic, uint32_t queue_size);
  bool get_latest_msg(BusType* busPtr); // returns true iff message is new

private:
  boost::shared_ptr<ros::CallbackQueue> customCallbackQueuePtr;
  ros::Subscriber subscriber;
  bool newMessageReceived;
  boost::shared_ptr<MsgType const> lastMsgPtr;
};

template <class MsgType, class BusType>
void SimulinkSubscriber<MsgType,BusType>::sub_callback(const boost::shared_ptr<MsgType const>& msgPtr) 
{
  lastMsgPtr = msgPtr; // copy the shared_ptr
  newMessageReceived = true;
}

template <class MsgType, class BusType>
void SimulinkSubscriber<MsgType,BusType>::create_subscriber(std::string const& topic, uint32_t queue_size)
{
  customCallbackQueuePtr.reset( new ros::CallbackQueue() );

  ros::SubscribeOptions opts;
  opts.init<MsgType>(topic, queue_size, 
	       boost::bind(&SimulinkSubscriber<MsgType,BusType>::sub_callback, this, _1));
  opts.callback_queue = customCallbackQueuePtr.get();
  
  subscriber = SLROSNodePtr->subscribe(opts);
}

// If return value is true, then a new message has been received
//    and *busPtr holds the newly-received message. 
// If return value is false, then a new message has not been received
//    and *busPtr is unchanged.
template <class MsgType, class BusType>
bool SimulinkSubscriber<MsgType,BusType>::get_latest_msg(BusType* busPtr) 
{
  customCallbackQueuePtr->callOne(); 

  if (newMessageReceived) {
    convert_to_bus(busPtr, lastMsgPtr.get());
    newMessageReceived = false;
    return true; // message is new
  } else {
    return false; // message is not new
  }
}


//---------------------------------
// Publisher template

template <class MsgType, class BusType>
class SimulinkPublisher
{

public:
  void create_publisher(std::string const& topic, uint32_t queue_size);
  void publish(BusType* busPtr);

private:
  ros::Publisher publisher;
  MsgType msg;
};

template <class MsgType, class BusType>
void SimulinkPublisher<MsgType,BusType>::create_publisher(std::string const& topic, uint32_t queue_size)
{
  publisher = SLROSNodePtr->advertise<MsgType>(topic, queue_size);
}

template <class MsgType, class BusType>
void SimulinkPublisher<MsgType,BusType>::publish(BusType* busPtr)
{
  convert_from_bus(&msg, busPtr);
  publisher.publish(msg);
}
