//
// File: dbx_control_data.cpp
//
// Code generated for Simulink model 'dbx_control'.
//
// Model version                  : 0.06
// Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
// C/C++ source code generated on : Sat Dec 02 12:31:04 2017
//
// Target selection: ert.tlc
// Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
// Emulation hardware selection:
//    Differs from embedded hardware (MATLAB Host)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
//    3. ROM efficiency
// Validation result: Not run
//
#include "dbx_control.h"
#include "dbx_control_private.h"

// Constant parameters (auto storage)
const ConstP_dbx_control_T dbx_control_ConstP = {
  // Pooled Parameter (Expression: OutValues)
  //  Referenced by:
  //    '<S2>/Lookup'
  //    '<S3>/Lookup'
  //    '<S4>/Lookup'
  //    '<S5>/Lookup'
  //    '<S6>/Lookup'
  //    '<S7>/Lookup'
  //    '<S8>/Lookup'

  { 3.0, 1.0, 4.0, 2.0, 1.0 },

  // Pooled Parameter (Expression: TimeValues)
  //  Referenced by:
  //    '<S2>/Lookup'
  //    '<S3>/Lookup'
  //    '<S4>/Lookup'
  //    '<S5>/Lookup'
  //    '<S6>/Lookup'
  //    '<S7>/Lookup'
  //    '<S8>/Lookup'

  { 0.0, 0.1, 0.5, 0.6, 1.0 }
};

//
// File trailer for generated code.
//
// [EOF]
//
