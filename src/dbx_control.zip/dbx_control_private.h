//
// File: dbx_control_private.h
//
// Code generated for Simulink model 'dbx_control'.
//
// Model version                  : 0.06
// Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
// C/C++ source code generated on : Sat Dec 02 12:31:04 2017
//
// Target selection: ert.tlc
// Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
// Emulation hardware selection:
//    Differs from embedded hardware (MATLAB Host)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
//    3. ROM efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_dbx_control_private_h_
#define RTW_HEADER_dbx_control_private_h_
#include "rtwtypes.h"

extern real_T look1_binlc(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif                                 // RTW_HEADER_dbx_control_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
