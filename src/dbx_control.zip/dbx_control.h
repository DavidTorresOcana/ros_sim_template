//
// File: dbx_control.h
//
// Code generated for Simulink model 'dbx_control'.
//
// Model version                  : 0.06
// Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
// C/C++ source code generated on : Sat Dec 02 12:31:04 2017
//
// Target selection: ert.tlc
// Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
// Emulation hardware selection:
//    Differs from embedded hardware (MATLAB Host)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
//    3. ROM efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_dbx_control_h_
#define RTW_HEADER_dbx_control_h_
#include <stddef.h>
#ifndef dbx_control_COMMON_INCLUDES_
# define dbx_control_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 // dbx_control_COMMON_INCLUDES_

#include "dbx_control_types.h"

// Macros for accessing real-time model data structure

// Block signals and states (auto storage) for system '<Root>'
typedef struct {
  real_T Gain1[7];                     // '<Root>/Gain1'
  uint8_T Output_DSTATE;               // '<S13>/Output'
  uint8_T Output_DSTATE_j;             // '<S16>/Output'
  uint8_T Output_DSTATE_jp;            // '<S19>/Output'
  uint8_T Output_DSTATE_g;             // '<S28>/Output'
  uint8_T Output_DSTATE_ja;            // '<S22>/Output'
  uint8_T Output_DSTATE_f;             // '<S25>/Output'
  uint8_T Output_DSTATE_j1;            // '<S31>/Output'
} DW_dbx_control_T;

// Constant parameters (auto storage)
typedef struct {
  // Pooled Parameter (Expression: OutValues)
  //  Referenced by:
  //    '<S2>/Lookup'
  //    '<S3>/Lookup'
  //    '<S4>/Lookup'
  //    '<S5>/Lookup'
  //    '<S6>/Lookup'
  //    '<S7>/Lookup'
  //    '<S8>/Lookup'

  real_T pooled2[5];

  // Pooled Parameter (Expression: TimeValues)
  //  Referenced by:
  //    '<S2>/Lookup'
  //    '<S3>/Lookup'
  //    '<S4>/Lookup'
  //    '<S5>/Lookup'
  //    '<S6>/Lookup'
  //    '<S7>/Lookup'
  //    '<S8>/Lookup'

  real_T pooled3[5];
} ConstP_dbx_control_T;

// External inputs (root inport signals with auto storage)
typedef struct {
  real_T ch1;                          // '<Root>/ch1'
  real_T ch2;                          // '<Root>/ch2'
  real_T ch3;                          // '<Root>/ch3'
  real_T ch4;                          // '<Root>/ch4'
  real_T ch5;                          // '<Root>/ch5'
  real_T ch6;                          // '<Root>/ch6'
  real_T ch7;                          // '<Root>/ch7'
  real_T ch8;                          // '<Root>/ch8'
  real_T gyro_x;                       // '<Root>/gyro_x'
  real_T gyro_y;                       // '<Root>/gyro_y'
  real_T gyro_z;                       // '<Root>/gyro_z'
  real_T acc_x;                        // '<Root>/acc_x'
  real_T acc_y;                        // '<Root>/acc_y'
  real_T acc_z;                        // '<Root>/acc_z'
  real_T mag_x;                        // '<Root>/mag_x'
  real_T mag_y;                        // '<Root>/mag_y'
  real_T mag_z;                        // '<Root>/mag_z'
  real_T baro_alt;                     // '<Root>/baro_alt'
  real_T gps_sat;                      // '<Root>/gps_sat'
  real_T gps_lat;                      // '<Root>/gps_lat'
  real_T gps_lon;                      // '<Root>/gps_lon'
  real_T gps_alt;                      // '<Root>/gps_alt'
  real_T gps_vel;                      // '<Root>/gps_vel'
  real_T gps_vel_n;                    // '<Root>/gps_vel_n'
  real_T gps_vel_e;                    // '<Root>/gps_vel_e'
  real_T gps_vel_d;                    // '<Root>/gps_vel_d'
  real_T rate_roll;                    // '<Root>/rate_roll'
  real_T rate_pitch;                   // '<Root>/rate_pitch'
  real_T rate_yaw;                     // '<Root>/rate_yaw'
  real_T att_roll;                     // '<Root>/att_roll'
  real_T att_pitch;                    // '<Root>/att_pitch'
  real_T att_yaw;                      // '<Root>/att_yaw'
  real_T q0;                           // '<Root>/q0'
  real_T q1;                           // '<Root>/q1'
  real_T q2;                           // '<Root>/q2'
  real_T q3;                           // '<Root>/q3'
  real_T runtime;                      // '<Root>/runtime'
  real_T gps_pdop;                     // '<Root>/gps_pdop'
  real_T gps_vdop;                     // '<Root>/gps_vdop'
  real_T bat_volts;                    // '<Root>/bat_volts'
  real_T pitot_diff_pre;               // '<Root>/pitot_diff_pre'
  real_T TAS_mps;                      // '<Root>/TAS_mps'
} ExtU_dbx_control_T;

// External outputs (root outports fed by signals with auto storage)
typedef struct {
  real_T pwm1;                         // '<Root>/pwm1'
  real_T pwm2;                         // '<Root>/pwm2'
  real_T pwm3;                         // '<Root>/pwm3'
  real_T pwm4;                         // '<Root>/pwm4'
  real_T pwm5;                         // '<Root>/pwm5'
  real_T pwm6;                         // '<Root>/pwm6'
  real_T pwm7;                         // '<Root>/pwm7'
  real_T pwm8;                         // '<Root>/pwm8'
  real_T pwm_arm;                      // '<Root>/pwm_arm'
  boolean_T led_blue;                  // '<Root>/led_blue'
  boolean_T led_red;                   // '<Root>/led_red'
  uint8_T rgb_red;                     // '<Root>/rgb_red'
  uint8_T rgb_green;                   // '<Root>/rgb_green'
  uint8_T rgb_blue;                    // '<Root>/rgb_blue'
  real_T debug1;                       // '<Root>/debug1'
  real_T debug2;                       // '<Root>/debug2'
  real_T debug3;                       // '<Root>/debug3'
  real_T debug4;                       // '<Root>/debug4'
  real_T debug5;                       // '<Root>/debug5'
  real_T debug6;                       // '<Root>/debug6'
  real_T debug7;                       // '<Root>/debug7'
  real_T debug8;                       // '<Root>/debug8'
} ExtY_dbx_control_T;

#ifdef __cplusplus

extern "C" {

#endif

#ifdef __cplusplus

}
#endif

// Constant parameters (auto storage)
extern const ConstP_dbx_control_T dbx_control_ConstP;

// Class declaration for model dbx_control
class dbx_controlModelClass {
  // public data and function members
 public:
  // External inputs
  ExtU_dbx_control_T dbx_control_U;

  // External outputs
  ExtY_dbx_control_T dbx_control_Y;

  // Model entry point functions

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  dbx_controlModelClass();

  // Destructor
  ~dbx_controlModelClass();

  // private data and function members
 private:
  // Block signals and states
  DW_dbx_control_T dbx_control_DW;
};

//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'dbx_control'
//  '<S1>'   : 'dbx_control/Px4_to_simulink input interface'
//  '<S2>'   : 'dbx_control/Repeating Sequence Interpolated'
//  '<S3>'   : 'dbx_control/Repeating Sequence Interpolated1'
//  '<S4>'   : 'dbx_control/Repeating Sequence Interpolated2'
//  '<S5>'   : 'dbx_control/Repeating Sequence Interpolated3'
//  '<S6>'   : 'dbx_control/Repeating Sequence Interpolated4'
//  '<S7>'   : 'dbx_control/Repeating Sequence Interpolated5'
//  '<S8>'   : 'dbx_control/Repeating Sequence Interpolated6'
//  '<S9>'   : 'dbx_control/Simulink_to_Px4 interface'
//  '<S10>'  : 'dbx_control/Px4_to_simulink input interface/Px4_to_simulink input interface'
//  '<S11>'  : 'dbx_control/Px4_to_simulink input interface/Px4_to_simulink input interface/DCM1'
//  '<S12>'  : 'dbx_control/Px4_to_simulink input interface/Px4_to_simulink input interface/MATLAB Function'
//  '<S13>'  : 'dbx_control/Repeating Sequence Interpolated/LimitedCounter'
//  '<S14>'  : 'dbx_control/Repeating Sequence Interpolated/LimitedCounter/Increment Real World'
//  '<S15>'  : 'dbx_control/Repeating Sequence Interpolated/LimitedCounter/Wrap To Zero'
//  '<S16>'  : 'dbx_control/Repeating Sequence Interpolated1/LimitedCounter'
//  '<S17>'  : 'dbx_control/Repeating Sequence Interpolated1/LimitedCounter/Increment Real World'
//  '<S18>'  : 'dbx_control/Repeating Sequence Interpolated1/LimitedCounter/Wrap To Zero'
//  '<S19>'  : 'dbx_control/Repeating Sequence Interpolated2/LimitedCounter'
//  '<S20>'  : 'dbx_control/Repeating Sequence Interpolated2/LimitedCounter/Increment Real World'
//  '<S21>'  : 'dbx_control/Repeating Sequence Interpolated2/LimitedCounter/Wrap To Zero'
//  '<S22>'  : 'dbx_control/Repeating Sequence Interpolated3/LimitedCounter'
//  '<S23>'  : 'dbx_control/Repeating Sequence Interpolated3/LimitedCounter/Increment Real World'
//  '<S24>'  : 'dbx_control/Repeating Sequence Interpolated3/LimitedCounter/Wrap To Zero'
//  '<S25>'  : 'dbx_control/Repeating Sequence Interpolated4/LimitedCounter'
//  '<S26>'  : 'dbx_control/Repeating Sequence Interpolated4/LimitedCounter/Increment Real World'
//  '<S27>'  : 'dbx_control/Repeating Sequence Interpolated4/LimitedCounter/Wrap To Zero'
//  '<S28>'  : 'dbx_control/Repeating Sequence Interpolated5/LimitedCounter'
//  '<S29>'  : 'dbx_control/Repeating Sequence Interpolated5/LimitedCounter/Increment Real World'
//  '<S30>'  : 'dbx_control/Repeating Sequence Interpolated5/LimitedCounter/Wrap To Zero'
//  '<S31>'  : 'dbx_control/Repeating Sequence Interpolated6/LimitedCounter'
//  '<S32>'  : 'dbx_control/Repeating Sequence Interpolated6/LimitedCounter/Increment Real World'
//  '<S33>'  : 'dbx_control/Repeating Sequence Interpolated6/LimitedCounter/Wrap To Zero'

#endif                                 // RTW_HEADER_dbx_control_h_

//
// File trailer for generated code.
//
// [EOF]
//
