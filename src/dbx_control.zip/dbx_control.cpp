//
// File: dbx_control.cpp
//
// Code generated for Simulink model 'dbx_control'.
//
// Model version                  : 0.06
// Simulink Coder version         : 8.8 (R2015a) 09-Feb-2015
// C/C++ source code generated on : Sat Dec 02 12:31:04 2017
//
// Target selection: ert.tlc
// Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
// Emulation hardware selection:
//    Differs from embedded hardware (MATLAB Host)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
//    3. ROM efficiency
// Validation result: Not run
//
#include "dbx_control.h"
#include "dbx_control_private.h"

real_T look1_binlc(real_T u0, const real_T bp0[], const real_T table[], uint32_T
                   maxIndex)
{
  real_T frac;
  uint32_T iRght;
  uint32_T iLeft;
  uint32_T bpIdx;

  // Lookup 1-D
  // Search method: 'binary'
  // Use previous index: 'off'
  // Interpolation method: 'Linear'
  // Extrapolation method: 'Clip'
  // Use last breakpoint for index at or above upper limit: 'off'
  // Remove protection against out-of-range input in generated code: 'off'

  // Prelookup - Index and Fraction
  // Index Search method: 'binary'
  // Extrapolation method: 'Clip'
  // Use previous index: 'off'
  // Use last breakpoint for index at or above upper limit: 'off'
  // Remove protection against out-of-range input in generated code: 'off'

  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = 0.0;
  } else if (u0 < bp0[maxIndex]) {
    // Binary Search
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = 1.0;
  }

  // Interpolation 1-D
  // Interpolation method: 'Linear'
  // Use last breakpoint for index at or above upper limit: 'off'
  // Overflow mode: 'wrapping'

  return (table[iLeft + 1U] - table[iLeft]) * frac + table[iLeft];
}

// Model step function
void dbx_controlModelClass::step()
{
  uint8_T rtb_FixPtSum1;
  real_T rtb_DataTypeConversion;
  uint8_T rtb_FixPtSum1_k;
  uint8_T rtb_FixPtSum1_a;
  uint8_T rtb_FixPtSum1_d;
  uint8_T rtb_FixPtSum1_p;
  uint8_T rtb_FixPtSum1_gx;
  uint8_T rtb_FixPtSum1_pg;
  int32_T i;

  // Lookup_n-D: '<S2>/Lookup' incorporates:
  //   DataTypeConversion: '<S2>/Data Type Conversion'
  //   SampleTimeMath: '<S2>/Sample Time Math'
  //   UnitDelay: '<S13>/Output'
  //
  //  About '<S2>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Outport: '<Root>/debug1' incorporates:
  //   Gain: '<Root>/Gain'

  dbx_control_Y.debug1 = rtb_DataTypeConversion;

  // Outport: '<Root>/pwm1' incorporates:
  //   Gain: '<Root>/Gain'

  dbx_control_Y.pwm1 = rtb_DataTypeConversion;

  // Outport: '<Root>/pwm2' incorporates:
  //   Gain: '<Root>/Gain'

  dbx_control_Y.pwm2 = rtb_DataTypeConversion;

  // Outport: '<Root>/pwm3' incorporates:
  //   Gain: '<Root>/Gain'

  dbx_control_Y.pwm3 = rtb_DataTypeConversion;

  // Lookup_n-D: '<S3>/Lookup' incorporates:
  //   DataTypeConversion: '<S3>/Data Type Conversion'
  //   SampleTimeMath: '<S3>/Sample Time Math'
  //   UnitDelay: '<S16>/Output'
  //
  //  About '<S3>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE_j *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Gain: '<Root>/Gain1'
  for (i = 0; i < 7; i++) {
    dbx_control_DW.Gain1[i] = rtb_DataTypeConversion;
  }

  // End of Gain: '<Root>/Gain1'

  // Outport: '<Root>/pwm4'
  dbx_control_Y.pwm4 = dbx_control_DW.Gain1[0];

  // Outport: '<Root>/pwm5'
  dbx_control_Y.pwm5 = dbx_control_DW.Gain1[1];

  // Outport: '<Root>/pwm6'
  dbx_control_Y.pwm6 = dbx_control_DW.Gain1[2];

  // Outport: '<Root>/pwm7'
  dbx_control_Y.pwm7 = dbx_control_DW.Gain1[3];

  // Outport: '<Root>/pwm8'
  dbx_control_Y.pwm8 = dbx_control_DW.Gain1[4];

  // Lookup_n-D: '<S4>/Lookup' incorporates:
  //   DataTypeConversion: '<S4>/Data Type Conversion'
  //   SampleTimeMath: '<S4>/Sample Time Math'
  //   UnitDelay: '<S19>/Output'
  //
  //  About '<S4>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE_jp *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Outport: '<Root>/pwm_arm'
  dbx_control_Y.pwm_arm = rtb_DataTypeConversion;

  // Lookup_n-D: '<S7>/Lookup' incorporates:
  //   DataTypeConversion: '<S7>/Data Type Conversion'
  //   SampleTimeMath: '<S7>/Sample Time Math'
  //   UnitDelay: '<S28>/Output'
  //
  //  About '<S7>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE_g *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Outport: '<Root>/led_blue' incorporates:
  //   DataTypeConversion: '<S9>/Data Type Conversion'

  dbx_control_Y.led_blue = true;

  // Outport: '<Root>/led_red' incorporates:
  //   DataTypeConversion: '<S9>/Data Type Conversion1'

  dbx_control_Y.led_red = true;

  // Outport: '<Root>/rgb_red' incorporates:
  //   DataTypeConversion: '<S9>/Data Type Conversion2'

  dbx_control_Y.rgb_red = (uint8_T)rtb_DataTypeConversion;

  // Outport: '<Root>/rgb_green' incorporates:
  //   DataTypeConversion: '<S9>/Data Type Conversion3'

  dbx_control_Y.rgb_green = (uint8_T)rtb_DataTypeConversion;

  // Outport: '<Root>/rgb_blue' incorporates:
  //   DataTypeConversion: '<S9>/Data Type Conversion4'

  dbx_control_Y.rgb_blue = (uint8_T)rtb_DataTypeConversion;

  // Lookup_n-D: '<S5>/Lookup' incorporates:
  //   DataTypeConversion: '<S5>/Data Type Conversion'
  //   SampleTimeMath: '<S5>/Sample Time Math'
  //   UnitDelay: '<S22>/Output'
  //
  //  About '<S5>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE_ja *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Outport: '<Root>/debug2'
  dbx_control_Y.debug2 = rtb_DataTypeConversion;

  // Lookup_n-D: '<S6>/Lookup' incorporates:
  //   DataTypeConversion: '<S6>/Data Type Conversion'
  //   SampleTimeMath: '<S6>/Sample Time Math'
  //   UnitDelay: '<S25>/Output'
  //
  //  About '<S6>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE_f *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Outport: '<Root>/debug3'
  dbx_control_Y.debug3 = rtb_DataTypeConversion;

  // Outport: '<Root>/debug4'
  dbx_control_Y.debug4 = 0.0;

  // Lookup_n-D: '<S8>/Lookup' incorporates:
  //   DataTypeConversion: '<S8>/Data Type Conversion'
  //   SampleTimeMath: '<S8>/Sample Time Math'
  //   UnitDelay: '<S31>/Output'
  //
  //  About '<S8>/Sample Time Math':
  //   y = u * K where K = ( w * Ts )

  rtb_DataTypeConversion = look1_binlc((real_T)dbx_control_DW.Output_DSTATE_j1 *
    0.05, *(real_T (*)[5])&dbx_control_ConstP.pooled3[0], *(real_T (*)[5])&
    dbx_control_ConstP.pooled2[0], 4U);

  // Outport: '<Root>/debug5' incorporates:
  //   Gain: '<Root>/Gain2'

  dbx_control_Y.debug5 = rtb_DataTypeConversion;

  // Outport: '<Root>/debug6' incorporates:
  //   Gain: '<Root>/Gain2'

  dbx_control_Y.debug6 = rtb_DataTypeConversion;

  // Outport: '<Root>/debug7' incorporates:
  //   Gain: '<Root>/Gain2'

  dbx_control_Y.debug7 = rtb_DataTypeConversion;

  // Outport: '<Root>/debug8' incorporates:
  //   Gain: '<Root>/Gain2'

  dbx_control_Y.debug8 = rtb_DataTypeConversion;

  // Sum: '<S14>/FixPt Sum1' incorporates:
  //   Constant: '<S14>/FixPt Constant'
  //   UnitDelay: '<S13>/Output'

  rtb_FixPtSum1 = (uint8_T)(dbx_control_DW.Output_DSTATE + 1U);

  // Sum: '<S17>/FixPt Sum1' incorporates:
  //   Constant: '<S17>/FixPt Constant'
  //   UnitDelay: '<S16>/Output'

  rtb_FixPtSum1_k = (uint8_T)(dbx_control_DW.Output_DSTATE_j + 1U);

  // Sum: '<S20>/FixPt Sum1' incorporates:
  //   Constant: '<S20>/FixPt Constant'
  //   UnitDelay: '<S19>/Output'

  rtb_FixPtSum1_a = (uint8_T)(dbx_control_DW.Output_DSTATE_jp + 1U);

  // Sum: '<S23>/FixPt Sum1' incorporates:
  //   Constant: '<S23>/FixPt Constant'
  //   UnitDelay: '<S22>/Output'

  rtb_FixPtSum1_p = (uint8_T)(dbx_control_DW.Output_DSTATE_ja + 1U);

  // Sum: '<S26>/FixPt Sum1' incorporates:
  //   Constant: '<S26>/FixPt Constant'
  //   UnitDelay: '<S25>/Output'

  rtb_FixPtSum1_gx = (uint8_T)(dbx_control_DW.Output_DSTATE_f + 1U);

  // Sum: '<S29>/FixPt Sum1' incorporates:
  //   Constant: '<S29>/FixPt Constant'
  //   UnitDelay: '<S28>/Output'

  rtb_FixPtSum1_d = (uint8_T)(dbx_control_DW.Output_DSTATE_g + 1U);

  // Sum: '<S32>/FixPt Sum1' incorporates:
  //   Constant: '<S32>/FixPt Constant'
  //   UnitDelay: '<S31>/Output'

  rtb_FixPtSum1_pg = (uint8_T)(dbx_control_DW.Output_DSTATE_j1 + 1U);

  // Switch: '<S15>/FixPt Switch'
  // MATLAB Function 'Px4_to_simulink input interface/Px4_to_simulink input interface/MATLAB Function': '<S12>:1' 
  // '<S12>:1:4'
  if (rtb_FixPtSum1 > 20) {
    // Update for UnitDelay: '<S13>/Output' incorporates:
    //   Constant: '<S15>/Constant'

    dbx_control_DW.Output_DSTATE = 0U;
  } else {
    // Update for UnitDelay: '<S13>/Output'
    dbx_control_DW.Output_DSTATE = rtb_FixPtSum1;
  }

  // End of Switch: '<S15>/FixPt Switch'

  // Switch: '<S18>/FixPt Switch'
  if (rtb_FixPtSum1_k > 20) {
    // Update for UnitDelay: '<S16>/Output' incorporates:
    //   Constant: '<S18>/Constant'

    dbx_control_DW.Output_DSTATE_j = 0U;
  } else {
    // Update for UnitDelay: '<S16>/Output'
    dbx_control_DW.Output_DSTATE_j = rtb_FixPtSum1_k;
  }

  // End of Switch: '<S18>/FixPt Switch'

  // Switch: '<S21>/FixPt Switch'
  if (rtb_FixPtSum1_a > 20) {
    // Update for UnitDelay: '<S19>/Output' incorporates:
    //   Constant: '<S21>/Constant'

    dbx_control_DW.Output_DSTATE_jp = 0U;
  } else {
    // Update for UnitDelay: '<S19>/Output'
    dbx_control_DW.Output_DSTATE_jp = rtb_FixPtSum1_a;
  }

  // End of Switch: '<S21>/FixPt Switch'

  // Switch: '<S30>/FixPt Switch'
  if (rtb_FixPtSum1_d > 20) {
    // Update for UnitDelay: '<S28>/Output' incorporates:
    //   Constant: '<S30>/Constant'

    dbx_control_DW.Output_DSTATE_g = 0U;
  } else {
    // Update for UnitDelay: '<S28>/Output'
    dbx_control_DW.Output_DSTATE_g = rtb_FixPtSum1_d;
  }

  // End of Switch: '<S30>/FixPt Switch'

  // Switch: '<S24>/FixPt Switch'
  if (rtb_FixPtSum1_p > 20) {
    // Update for UnitDelay: '<S22>/Output' incorporates:
    //   Constant: '<S24>/Constant'

    dbx_control_DW.Output_DSTATE_ja = 0U;
  } else {
    // Update for UnitDelay: '<S22>/Output'
    dbx_control_DW.Output_DSTATE_ja = rtb_FixPtSum1_p;
  }

  // End of Switch: '<S24>/FixPt Switch'

  // Switch: '<S27>/FixPt Switch'
  if (rtb_FixPtSum1_gx > 20) {
    // Update for UnitDelay: '<S25>/Output' incorporates:
    //   Constant: '<S27>/Constant'

    dbx_control_DW.Output_DSTATE_f = 0U;
  } else {
    // Update for UnitDelay: '<S25>/Output'
    dbx_control_DW.Output_DSTATE_f = rtb_FixPtSum1_gx;
  }

  // End of Switch: '<S27>/FixPt Switch'

  // Switch: '<S33>/FixPt Switch'
  if (rtb_FixPtSum1_pg > 20) {
    // Update for UnitDelay: '<S31>/Output' incorporates:
    //   Constant: '<S33>/Constant'

    dbx_control_DW.Output_DSTATE_j1 = 0U;
  } else {
    // Update for UnitDelay: '<S31>/Output'
    dbx_control_DW.Output_DSTATE_j1 = rtb_FixPtSum1_pg;
  }

  // End of Switch: '<S33>/FixPt Switch'
}

// Model initialize function
void dbx_controlModelClass::initialize()
{
  // (no initialization code required)
}

// Model terminate function
void dbx_controlModelClass::terminate()
{
  // (no terminate code required)
}

// Constructor
dbx_controlModelClass::dbx_controlModelClass()
{
}

// Destructor
dbx_controlModelClass::~dbx_controlModelClass()
{
  // Currently there is no destructor body generated.
}

//
// File trailer for generated code.
//
// [EOF]
//
